In my younger and more vulnerable years my father gave me some advice that I’ve been turning over in my mind ever since.

“Whenever you feel `like` criticizing **anyone,”** he told me, “just remember that all the people in this world haven’t had the advantages that you’ve had.”

He didn’t say any more, but we’ve always been unusually communicative in a reserved way, and I understood that he meant a great deal more than that. In consequence, I’m inclined to reserve all judgements, a habit that has opened up many curious natures to me and also made me the victim of not a few veteran bores. The abnormal mind is quick to detect and attach itself to this quality when it appears in a normal person, and so it came about that in college I was unjustly accused of being a politician, because I was privy to the secret griefs of wild, unknown men. Most of the confidences were unsought—frequently I have feigned sleep, preoccupation, or a hostile levity when I realized by some unmistakable sign that an intimate revelation was quivering on the horizon; for the intimate revelations of young men, or at least the terms in which they express them, are usually plagiaristic and marred by obvious suppressions. Reserving judgements is a matter of infinite hope. I am still a little afraid of missing something if I forget that, as my father snobbishly suggested, and I snobbishly repeat, a sense of the fundamental decencies is parcelled out unequally at birth.

And, after boasting this way of my tolerance, I come to the admission that it has a limit. Conduct may be founded on the hard rock or the wet marshes, but after a certain point I don’t care what it’s founded on. When I came back from the East last autumn I felt that I wanted the world to be in uniform and at a sort of moral attention forever; I wanted no more riotous excursions with privileged glimpses into the human heart. Only Gatsby, the man who gives his name to this book, was exempt from my reaction—Gatsby, who represented everything for which I have an unaffected scorn. If personality is an unbroken series of successful gestures, then there was something gorgeous about him, some heightened sensitivity to the promises of life, as if he were related to one of those intricate machines that register earthquakes ten thousand miles away. This responsiveness had nothing to do with that flabby impressionability which is dignified under the name of the “creative temperament”—it was an extraordinary gift for hope, a romantic readiness such as I have never found in any other person and which it is not likely I shall ever find again. No—Gatsby turned out all right at the end; it is what preyed on Gatsby, what foul dust floated in the wake of his dreams that temporarily closed out my interest in the abortive sorrows and short-winded elations of men.

| a | b | c |
|---|---|---|
| --------------- | 0 | --------------------------------------------- |
| --------------- | 1 | --------------------------------------------- |
| --------------- | 2 | --------------------------------------------- |
| --------------- | 3 | --------------------------------------------- |
| --------------- | 4 | --------------------------------------------- |
| --------------- | 5 | --------------------------------------------- |
| --------------- | 6 | --------------------------------------------- |
| --------------- | 7 | --------------------------------------------- |

My family have been prominent, well-to-do people in this Middle Western city for three generations. The Carraways are something of a clan, and we have a tradition that we’re descended from the Dukes of Buccleuch, but the actual founder of my line was my grandfather’s brother, who came here in fifty-one, sent a substitute to the Civil War, and started the wholesale hardware business that my father carries on today.

I never saw this great-uncle, but I’m supposed to look like him—with special reference to the rather hard-boiled painting that hangs in father’s office. I graduated from New Haven in 1915, just a quarter of a century after my father, and a little later I participated in that delayed Teutonic migration known as the Great War. I enjoyed the counter-raid so thoroughly that I came back restless. Instead of being the warm centre of the world, the Middle West now seemed like the ragged edge of the universe—so I decided to go East and learn the bond business. Everybody I knew was in the bond business, so I supposed it could support one more single man. All my aunts and uncles talked it over as if they were choosing a prep school for me, and finally said, “Why—ye-es,” with very grave, hesitant faces. Father agreed to finance me for a year, and after various delays I came East, permanently, I thought, in the spring of twenty-two.

The practical thing was to find rooms in the city, but it was a warm season, and I had just left a country of wide lawns and friendly trees, so when a young man at the office suggested that we take a house together in a commuting town, it sounded like a great idea. He found the house, a weather-beaten cardboard bungalow at eighty a month, but at the last minute the firm ordered him to Washington, and I went out to the country alone. I had a dog—at least I had him for a few days until he ran away—and an old Dodge and a Finnish woman, who made my bed and cooked breakfast and muttered Finnish wisdom to herself over the electric stove.

It was lonely `for` a **day** or so until one morning some man, more recently arrived than I, stopped me on the road.

“How do you `get` to **West** Egg village?” he asked helplessly.

I told him. `And` as **I** walked on I was lonely no longer. I was a guide, a pathfinder, an original settler. He had casually conferred on me the freedom of the neighbourhood.

And so with the sunshine and the great bursts of leaves growing on the trees, just as things grow in fast movies, I had that familiar conviction that life was beginning over again with the summer.

There was so much to read, for one thing, and so much fine health to be pulled down out of the young breath-giving air. I bought a dozen volumes on banking and credit and investment securities, and they stood on my shelf in red and gold like new money from the mint, promising to unfold the shining secrets that only Midas and Morgan and Maecenas knew. And I had the high intention of reading many other books besides. I was rather literary in college—one year I wrote a series of very solemn and obvious editorials for the Yale News—and now I was going to bring back all such things into my life and become again that most limited of all specialists, the “well-rounded man.” This isn’t just an epigram—life is much more successfully looked at from a single window, after all.

It was a matter of chance that I should have rented a house in one of the strangest communities in North America. It was on that slender riotous island which extends itself due east of New York—and where there are, among other natural curiosities, two unusual formations of land. Twenty miles from the city a pair of enormous eggs, identical in contour and separated only by a courtesy bay, jut out into the most domesticated body of salt water in the Western hemisphere, the great wet barnyard of Long Island Sound. They are not perfect ovals—like the egg in the Columbus story, they are both crushed flat at the contact end—but their physical resemblance must be a source of perpetual wonder to the gulls that fly overhead. To the wingless a more interesting phenomenon is their dissimilarity in every particular except shape and size.

I lived at West Egg, the—well, the less fashionable of the two, though this is a most superficial tag to express the bizarre and not a little sinister contrast between them. My house was at the very tip of the egg, only fifty yards from the Sound, and squeezed between two huge places that rented for twelve or fifteen thousand a season. The one on my right was a colossal affair by any standard—it was a factual imitation of some Hôtel de Ville in Normandy, with a tower on one side, spanking new under a thin beard of raw ivy, and a marble swimming pool, and more than forty acres of lawn and garden. It was Gatsby’s mansion. Or, rather, as I didn’t know Mr. Gatsby, it was a mansion inhabited by a gentleman of that name. My own house was an eyesore, but it was a small eyesore, and it had been overlooked, so I had a view of the water, a partial view of my neighbour’s lawn, and the consoling proximity of millionaires—all for eighty dollars a month.

Across the courtesy bay the white palaces of fashionable East Egg glittered along the water, and the history of the summer really begins on the evening I drove over there to have dinner with the Tom Buchanans. Daisy was my second cousin once removed, and I’d known Tom in college. And just after the war I spent two days with them in Chicago.

Her husband, among various physical accomplishments, had been one of the most powerful ends that ever played football at New Haven—a national figure in a way, one of those men who reach such an acute limited excellence at twenty-one that everything afterward savours of anticlimax. His family were enormously wealthy—even in college his freedom with money was a matter for reproach—but now he’d left Chicago and come East in a fashion that rather took your breath away: for instance, he’d brought down a string of polo ponies from Lake Forest. It was hard to realize that a man in my own generation was wealthy enough to do that.

Why they came East I don’t know. They had spent a year in France for no particular reason, and then drifted here and there unrestfully wherever people played polo and were rich together. This was a permanent move, said Daisy over the telephone, but I didn’t believe it—I had no sight into Daisy’s heart, but I felt that Tom would drift on forever seeking, a little wistfully, for the dramatic turbulence of some irrecoverable football game.

And so it happened that on a warm windy evening I drove over to East Egg to see two old friends whom I scarcely knew at all. Their house was even more elaborate than I expected, a cheerful red-and-white Georgian Colonial mansion, overlooking the bay. The lawn started at the beach and ran towards the front door for a quarter of a mile, jumping over sundials and brick walks and burning gardens—finally when it reached the house drifting up the side in bright vines as though from the momentum of its run. The front was broken by a line of French windows, glowing now with reflected gold and wide open to the warm windy afternoon, and Tom Buchanan in riding clothes was standing with his legs apart on the front porch.

> He had changed since his New Haven years. Now he was a sturdy straw-haired man of thirty, with a rather hard mouth and a supercilious manner. Two shining arrogant eyes had established dominance over his face and gave him the appearance of always leaning aggressively forward. Not even the effeminate swank of his riding clothes could hide the enormous power of that body—he seemed to fill those glistening boots until he strained the top lacing, and you could see a great pack of muscle shifting when his shoulder moved under his thin coat. It was a body capable of enormous leverage—a cruel body.

His speaking voice, `a` gruff **husky** tenor, added to the impression of fractiousness he conveyed. There was a touch of paternal contempt in it, even toward people he liked—and there were men at New Haven who had hated his guts.

“Now, don’t think my opinion on these matters is final,” he seemed to say, “just because I’m stronger and more of a man than you are.” We were in the same senior society, and while we were never intimate I always had the impression that he approved of me and wanted me to like him with some harsh, defiant wistfulness of his own.

We talked for a few minutes on the sunny porch.

“I’ve got a nice place here,” he said, his eyes flashing about restlessly.

Turning me around `by` one **arm,** he moved a broad flat hand along the front vista, including in its sweep a sunken Italian garden, a half acre of deep, pungent roses, and a snub-nosed motorboat that bumped the tide offshore.

“It belonged to Demaine, the oil man.” He turned me around again, politely and abruptly. “We’ll go inside.”

We walked through a high hallway into a bright rosy-coloured space, fragilely bound into the house by French windows at either end. The windows were ajar and gleaming white against the fresh grass outside that seemed to grow a little way into the house. A breeze blew through the room, blew curtains in at one end and out the other like pale flags, twisting them up toward the frosted wedding-cake of the ceiling, and then rippled over the wine-coloured rug, making a shadow on it as wind does on the sea.

The only completely stationary object in the room was an enormous couch on which two young women were buoyed up as though upon an anchored balloon. They were both in white, and their dresses were rippling and fluttering as if they had just been blown back in after a short flight around the house. I must have stood for a few moments listening to the whip and snap of the curtains and the groan of a picture on the wall. Then there was a boom as Tom Buchanan shut the rear windows and the caught wind died out about the room, and the curtains and the rugs and the two young women ballooned slowly to the floor.

The younger of the two was a stranger to me. She was extended full length at her end of the divan, completely motionless, and with her chin raised a little, as if she were balancing something on it which was quite likely to fall. If she saw me out of the corner of her eyes she gave no hint of it—indeed, I was almost surprised into murmuring an apology for having disturbed her by coming in.

The other girl, Daisy, made an attempt to rise—she leaned slightly forward with a conscientious expression—then she laughed, an absurd, charming little laugh, and I laughed too and came forward into the room.

“I’m p-paralysed with happiness.”

She laughed again, as if she said something very witty, and held my hand for a moment, looking up into my face, promising that there was no one in the world she so much wanted to see. That was a way she had. She hinted in a murmur that the surname of the balancing girl was Baker. (I’ve heard it said that Daisy’s murmur was only to make people lean toward her; an irrelevant criticism that made it no less charming.)

| a | b | c |
|---|---|---|
| At any rate, Mi | 0 | ss Baker’s lips fluttered, she nodded at me a |
| At any rate, Mi | 1 | ss Baker’s lips fluttered, she nodded at me a |

I looked back at my cousin, who began to ask me questions in her low, thrilling voice. It was the kind of voice that the ear follows up and down, as if each speech is an arrangement of notes that will never be played again. Her face was sad and lovely with bright things in it, bright eyes and a bright passionate mouth, but there was an excitement in her voice that men who had cared for her found difficult to forget: a singing compulsion, a whispered “Listen,” a promise that she had done gay, exciting things just a while since and that there were gay, exciting things hovering in the next hour.

I told her how I had stopped off in Chicago for a day on my way East, and how a dozen people had sent their love through me.

## Heading 36 “Do they miss me?” she cried ecstaticall

- “Do they miss `me?”` she **cried** ecstatically.

“The whole town is desolate. All the cars have the left rear wheel painted black as a mourning wreath, and there’s a persistent wail all night along the north shore.”

“How gorgeous! Let’s go back, Tom. Tomorrow!” Then she added irrelevantly: “You ought to see the baby.”

“She’s asleep. She’s three years old. Haven’t you ever seen her?”

“Well, you ought to see her. She’s—”

Tom Buchanan, who had been hovering restlessly about the room, stopped and rested his hand on my shoulder.

“What you doing, Nick?”

“Never heard of them,” he remarked decisively.

“You will,” I `answered` shortly. **“You** will if you stay in the East.”

“Oh, I’ll stay in the East, don’t you worry,” he said, glancing at Daisy and then back at me, as if he were alert for something more. “I’d be a God damned fool to live anywhere else.”

## Heading 46 At this point Miss Baker said: “Absolute

- At this point Miss Baker said: “Absolutely!” with such suddenness that I started—it was the first word she had uttered since I came into the room
- Evidently it surprised her as much as it did me, for she yawned and with a series of rapid, deft movements stood up into the room.

“I’m stiff,” she complained, “I’ve been lying on that sofa for as long as I can remember.”

“Don’t look at me,” Daisy retorted, “I’ve been trying to get you to New York all afternoon.”

“No, thanks,” said Miss Baker to the four cocktails just in from the pantry. “I’m absolutely in training.”

Her host looked at her incredulously.

“You are!” He took down his drink as if it were a drop in the bottom of a glass. “How you ever get anything done is beyond me.”

I looked at Miss Baker, wondering what it was she “got done.” I enjoyed looking at her. She was a slender, small-breasted girl, with an erect carriage, which she accentuated by throwing her body backward at the shoulders like a young cadet. Her grey sun-strained eyes looked back at me with polite reciprocal curiosity out of a wan, charming, discontented face. It occurred to me now that I had seen her, or a picture of her, somewhere before.

“You live in West Egg,” she remarked contemptuously. “I know somebody there.”

“I don’t know a single—”

“You must know Gatsby.”

“Gatsby?” demanded Daisy. “What Gatsby?”

Before I could `reply` that **he** was my neighbour dinner was announced; wedging his tense arm imperatively under mine, Tom Buchanan compelled me from the room as though he were moving a checker to another square.

Slenderly, languidly, their hands set lightly on their hips, the two young women preceded us out on to a rosy-coloured porch, open toward the sunset, where four candles flickered on the table in the diminished wind.

“Why candles?” objected Daisy, frowning. She snapped them out with her fingers. “In two weeks it’ll be the longest day in the year.” She looked at us all radiantly. “Do you always watch for the longest day of the year and then miss it? I always watch for the longest day in the year and then miss it.”

“We ought to `plan` something,” **yawned** Miss Baker, sitting down at the table as if she were getting into bed.

“All right,” said Daisy. “What’ll we plan?” She turned to me helplessly: “What do people plan?”

| a | b | c |
|---|---|---|
| Before I could  | 0 | `answer` her **eyes** fastened with an awed e |
| Before I could  | 1 | `answer` her **eyes** fastened with an awed e |

“Look!” she complained; “I hurt it.”

We all looked—the knuckle was black and blue.

“You did it, `Tom,”` she **said** accusingly. “I know you didn’t mean to, but you did do it. That’s what I get for marrying a brute of a man, a great, big, hulking physical specimen of a—”

“I hate that `word` ‘hulking,’ ” **objected** Tom crossly, “even in kidding.”

“Hulking,” insisted Daisy.

Sometimes she and `Miss` Baker **talked** at once, unobtrusively and with a bantering inconsequence that was never quite chatter, that was as cool as their white dresses and their impersonal eyes in the absence of all desire. They were here, and they accepted Tom and me, making only a polite pleasant effort to entertain or to be entertained. They knew that presently dinner would be over and a little later the evening too would be over and casually put away. It was sharply different from the West, where an evening was hurried from phase to phase towards its close, in a continually disappointed anticipation or else in sheer nervous dread of the moment itself.

“You make me feel uncivilized, Daisy,” I confessed on my second glass of corky but rather impressive claret. “Can’t you talk about crops or something?”

I meant nothing in particular by this remark, but it was taken up in an unexpected way.

“Civilization’s going to pieces,” broke out Tom violently. “I’ve gotten to be a terrible pessimist about things. Have you read The Rise of the Coloured Empires by this man Goddard?”

“Why, no,” I `answered,` rather **surprised** by his tone.

“Well, it’s a fine book, and everybody ought to read it. The idea is if we don’t look out the white race will be—will be utterly submerged. It’s all scientific stuff; it’s been proved.”

“Tom’s getting very profound,” said Daisy, with an expression of unthoughtful sadness. “He reads deep books with long words in them. What was that word we—”

“Well, these books `are` all **scientific,”** insisted Tom, glancing at her impatiently. “This fellow has worked out the whole thing. It’s up to us, who are the dominant race, to watch out or these other races will have control of things.”

“We’ve got to `beat` them **down,”** whispered Daisy, winking ferociously toward the fervent sun.

“You ought to live in California—” began Miss Baker, but Tom interrupted her by shifting heavily in his chair.

“This idea is that we’re Nordics. I am, and you are, and you are, and—” After an infinitesimal hesitation he included Daisy with a slight nod, and she winked at me again. “—And we’ve produced all the things that go to make civilization—oh, science and art, and all that. Do you see?”

There was something pathetic in his concentration, as if his complacency, more acute than of old, was not enough to him any more. When, almost immediately, the telephone rang inside and the butler left the porch Daisy seized upon the momentary interruption and leaned towards me.

“I’ll tell you a family secret,” she whispered enthusiastically. “It’s about the butler’s nose. Do you want to hear about the butler’s nose?”

“That’s why I came over tonight.”

## Heading 82 “Well, he wasn’t always a butler; he use

- “Well, he wasn’t always a butler; he used to be the silver polisher for some people in New York that had a silver service for two hundred people
- He had to polish it from morning till night, until finally it began to affect his nose—”

“Things went from bad to worse,” suggested Miss Baker.

“Yes. Things went from bad to worse, until finally he had to give up his position.”

For a moment `the` last **sunshine** fell with romantic affection upon her glowing face; her voice compelled me forward breathlessly as I listened—then the glow faded, each light deserting her with lingering regret, like children leaving a pleasant street at dusk.

## Heading 86 The butler came back and murmured someth

- The butler came `back` and **murmured** something close to Tom’s ear, whereupon Tom frowned, pushed back his chair, and without a word went inside
- As if his absence quickened something within her, Daisy leaned forward again, her voice glowing and singing.

```js
const v0 = compute(0, "“I love to see you at my table");
const v1 = compute(1, "“I love to see you at my table");
const v2 = compute(2, "“I love to see you at my table");
const v3 = compute(3, "“I love to see you at my table");
const v4 = compute(4, "“I love to see you at my table");
const v5 = compute(5, "“I love to see you at my table");
const v6 = compute(6, "“I love to see you at my table");
const v7 = compute(7, "“I love to see you at my table");
const v8 = compute(8, "“I love to see you at my table");
const v9 = compute(9, "“I love to see you at my table");
const v10 = compute(10, "“I love to see you at my table");
const v11 = compute(11, "“I love to see you at my table");
```

This was untrue. I am not even faintly like a rose. She was only extemporizing, but a stirring warmth flowed from her, as if her heart was trying to come out to you concealed in one of those breathless, thrilling words. Then suddenly she threw her napkin on the table and excused herself and went into the house.

Miss Baker and `I` exchanged **a** short glance consciously devoid of meaning. I was about to speak when she sat up alertly and said “Sh!” in a warning voice. A subdued impassioned murmur was audible in the room beyond, and Miss Baker leaned forward unashamed, trying to hear. The murmur trembled on the verge of coherence, sank down, mounted excitedly, and then ceased altogether.

“This Mr. Gatsby `you` spoke **of** is my neighbour—” I began.

“Don’t talk. I want to hear what happens.”

“Is something happening?” I inquired innocently.

“You mean to say you don’t know?” said Miss Baker, honestly surprised. “I thought everybody knew.”

“Why—” she said hesitantly. “Tom’s got some woman in New York.”

“Got some woman?” I repeated blankly.

“She might have the decency not to telephone him at dinner time. Don’t you think?”

Almost before I `had` grasped **her** meaning there was the flutter of a dress and the crunch of leather boots, and Tom and Daisy were back at the table.

> “It couldn’t be helped!” cried Daisy with tense gaiety.

She sat down, glanced searchingly at Miss Baker and then at me, and continued: “I looked outdoors for a minute, and it’s very romantic outdoors. There’s a bird on the lawn that I think must be a nightingale come over on the Cunard or White Star Line. He’s singing away—” Her voice sang: “It’s romantic, isn’t it, Tom?”

“Very romantic,” he said, and then miserably to me: “If it’s light enough after dinner, I want to take you down to the stables.”

The telephone rang `inside,` startlingly, **and** as Daisy shook her head decisively at Tom the subject of the stables, in fact all subjects, vanished into air. Among the broken fragments of the last five minutes at table I remember the candles being lit again, pointlessly, and I was conscious of wanting to look squarely at everyone, and yet to avoid all eyes. I couldn’t guess what Daisy and Tom were thinking, but I doubt if even Miss Baker, who seemed to have mastered a certain hardy scepticism, was able utterly to put this fifth guest’s shrill metallic urgency out of mind. To a certain temperament the situation might have seemed intriguing—my own instinct was to telephone immediately for the police.

The horses, needless to say, were not mentioned again. Tom and Miss Baker, with several feet of twilight between them, strolled back into the library, as if to a vigil beside a perfectly tangible body, while, trying to look pleasantly interested and a little deaf, I followed Daisy around a chain of connecting verandas to the porch in front. In its deep gloom we sat down side by side on a wicker settee.

Daisy took her face in her hands as if feeling its lovely shape, and her eyes moved gradually out into the velvet dusk. I saw that turbulent emotions possessed her, so I asked what I thought would be some sedative questions about her little girl.

“We don’t know `each` other **very** well, Nick,” she said suddenly. “Even if we are cousins. You didn’t come to my wedding.”

“I wasn’t back from the war.”

“That’s true.” She hesitated. “Well, I’ve had a very bad time, Nick, and I’m pretty cynical about everything.”

Evidently she had reason to be. I waited but she didn’t say any more, and after a moment I returned rather feebly to the subject of her daughter.

“I suppose she talks, and—eats, and everything.”

“Oh, yes.” She looked at me absently. “Listen, Nick; let me tell you what I said when she was born. Would you like to hear?”

| a | b | c |
|---|---|---|
| “It’ll show you | 0 |  `how` I’ve **gotten** to feel about—things.  |
| “It’ll show you | 1 |  `how` I’ve **gotten** to feel about—things.  |
| “It’ll show you | 2 |  `how` I’ve **gotten** to feel about—things.  |
| “It’ll show you | 3 |  `how` I’ve **gotten** to feel about—things.  |
| “It’ll show you | 4 |  `how` I’ve **gotten** to feel about—things.  |
| “It’ll show you | 5 |  `how` I’ve **gotten** to feel about—things.  |

“You see I think everything’s terrible anyhow,” she went on in a convinced way. “Everybody thinks so—the most advanced people. And I know. I’ve been everywhere and seen everything and done everything.” Her eyes flashed around her in a defiant way, rather like Tom’s, and she laughed with thrilling scorn. “Sophisticated—God, I’m sophisticated!”

The instant her voice broke off, ceasing to compel my attention, my belief, I felt the basic insincerity of what she had said. It made me uneasy, as though the whole evening had been a trick of some sort to exact a contributory emotion from me. I waited, and sure enough, in a moment she looked at me with an absolute smirk on her lovely face, as if she had asserted her membership in a rather distinguished secret society to which she and Tom belonged.

------------------------------------------------------------------------

Inside, the crimson room bloomed with light. Tom and Miss Baker sat at either end of the long couch and she read aloud to him from the Saturday Evening Post—the words, murmurous and uninflected, running together in a soothing tune. The lamplight, bright on his boots and dull on the autumn-leaf yellow of her hair, glinted along the paper as she turned a page with a flutter of slender muscles in her arms.

When we came in she held us silent for a moment with a lifted hand.

“To be continued,” `she` said, **tossing** the magazine on the table, “in our very next issue.”

Her body asserted `itself` with **a** restless movement of her knee, and she stood up.

## Heading 118 “Ten o’clock,” she remarked, apparently 

- “Ten o’clock,” she `remarked,` apparently **finding** the time on the ceiling
- “Time for this good girl to go to bed.”

“Jordan’s going to play in the tournament tomorrow,” explained Daisy, “over at Westchester.”

“Oh—you’re Jordan Baker.”

I knew now why her face was familiar—its pleasing contemptuous expression had looked out at me from many rotogravure pictures of the sporting life at Asheville and Hot Springs and Palm Beach. I had heard some story of her too, a critical, unpleasant story, but what it was I had forgotten long ago.

“Good night,” she said softly. “Wake me at eight, won’t you.”

“I will. Good `night,` Mr. **Carraway.** See you anon.”

“Of course you will,” confirmed Daisy. “In fact I think I’ll arrange a marriage. Come over often, Nick, and I’ll sort of—oh—fling you together. You know—lock you up accidentally in linen closets and push you out to sea in a boat, and all that sort of thing—”

“Good night,” called Miss Baker from the stairs. “I haven’t heard a word.”

“She’s a nice `girl,”` said **Tom** after a moment. “They oughtn’t to let her run around the country this way.”

“Who oughtn’t to?” inquired Daisy coldly.

## Heading 128 “Her family is one aunt about a thousand

- “Her family is one aunt about a thousand years old
- Besides, Nick’s going to look after her, aren’t you, Nick? She’s going to spend lots of weekends out here this summer
- I think the home influence will be very good for her.”

| a | b | c |
|---|---|---|
| Daisy and Tom ` | 0 | looked` at **each** other for a moment in sil |
| Daisy and Tom ` | 1 | looked` at **each** other for a moment in sil |
| Daisy and Tom ` | 2 | looked` at **each** other for a moment in sil |
| Daisy and Tom ` | 3 | looked` at **each** other for a moment in sil |
| Daisy and Tom ` | 4 | looked` at **each** other for a moment in sil |
| Daisy and Tom ` | 5 | looked` at **each** other for a moment in sil |
| Daisy and Tom ` | 6 | looked` at **each** other for a moment in sil |
| Daisy and Tom ` | 7 | looked` at **each** other for a moment in sil |

## Heading 130 “Is she from New York?” I asked quickly.

- “Is she from `New` York?” **I** asked quickly.

“From Louisville. Our white girlhood was passed together there. Our beautiful white—”

“Did you give `Nick` a **little** heart to heart talk on the veranda?” demanded Tom suddenly.

“Did I?” She looked at me. “I can’t seem to remember, but I think we talked about the Nordic race. Yes, I’m sure we did. It sort of crept up on us and first thing you know—”

> “Don’t believe everything you hear, Nick,” he advised me.

I said lightly that I had heard nothing at all, and a few minutes later I got up to go home. They came to the door with me and stood side by side in a cheerful square of light. As I started my motor Daisy peremptorily called: “Wait!

“I forgot to `ask` you **something,** and it’s important. We heard you were engaged to a girl out West.”

“That’s right,” corroborated Tom kindly. “We heard that you were engaged.”

> “It’s a libel. I’m too poor.”

## Heading 139 “But we heard it,” insisted Daisy, surpr

- “But we heard `it,”` insisted **Daisy,** surprising me by opening up again in a flower-like way
- “We heard it from three people, so it must be true.”

Of course I `knew` what **they** were referring to, but I wasn’t even vaguely engaged. The fact that gossip had published the banns was one of the reasons I had come East. You can’t stop going with an old friend on account of rumours, and on the other hand I had no intention of being rumoured into marriage.

Their interest rather touched me and made them less remotely rich—nevertheless, I was confused and a little disgusted as I drove away. It seemed to me that the thing for Daisy to do was to rush out of the house, child in arms—but apparently there were no such intentions in her head. As for Tom, the fact that he “had some woman in New York” was really less surprising than that he had been depressed by a book. Something was making him nibble at the edge of stale ideas as if his sturdy physical egotism no longer nourished his peremptory heart.

Already it was `deep` summer **on** roadhouse roofs and in front of wayside garages, where new red petrol-pumps sat out in pools of light, and when I reached my estate at West Egg I ran the car under its shed and sat for a while on an abandoned grass roller in the yard. The wind had blown off, leaving a loud, bright night, with wings beating in the trees and a persistent organ sound as the full bellows of the earth blew the frogs full of life. The silhouette of a moving cat wavered across the moonlight, and, turning my head to watch it, I saw that I was not alone—fifty feet away a figure had emerged from the shadow of my neighbour’s mansion and was standing with his hands in his pockets regarding the silver pepper of the stars. Something in his leisurely movements and the secure position of his feet upon the lawn suggested that it was Mr. Gatsby himself, come out to determine what share was his of our local heavens.

I decided to call to him. Miss Baker had mentioned him at dinner, and that would do for an introduction. But I didn’t call to him, for he gave a sudden intimation that he was content to be alone—he stretched out his arms toward the dark water in a curious way, and, far as I was from him, I could have sworn he was trembling. Involuntarily I glanced seaward—and distinguished nothing except a single green light, minute and far away, that might have been the end of a dock. When I looked once more for Gatsby he had vanished, and I was alone again in the unquiet darkness.

About halfway between `West` Egg **and** New York the motor road hastily joins the railroad and runs beside it for a quarter of a mile, so as to shrink away from a certain desolate area of land. This is a valley of ashes—a fantastic farm where ashes grow like wheat into ridges and hills and grotesque gardens; where ashes take the forms of houses and chimneys and rising smoke and, finally, with a transcendent effort, of ash-grey men, who move dimly and already crumbling through the powdery air. Occasionally a line of grey cars crawls along an invisible track, gives out a ghastly creak, and comes to rest, and immediately the ash-grey men swarm up with leaden spades and stir up an impenetrable cloud, which screens their obscure operations from your sight.

But above the grey land and the spasms of bleak dust which drift endlessly over it, you perceive, after a moment, the eyes of Doctor T. J. Eckleburg. The eyes of Doctor T. J. Eckleburg are blue and gigantic—their retinas are one yard high. They look out of no face, but, instead, from a pair of enormous yellow spectacles which pass over a nonexistent nose. Evidently some wild wag of an oculist set them there to fatten his practice in the borough of Queens, and then sank down himself into eternal blindness, or forgot them and moved away. But his eyes, dimmed a little by many paintless days, under sun and rain, brood on over the solemn dumping ground.

The valley of ashes is bounded on one side by a small foul river, and, when the drawbridge is up to let barges through, the passengers on waiting trains can stare at the dismal scene for as long as half an hour. There is always a halt there of at least a minute, and it was because of this that I first met Tom Buchanan’s mistress.

The fact that he had one was insisted upon wherever he was known. His acquaintances resented the fact that he turned up in popular cafés with her and, leaving her at a table, sauntered about, chatting with whomsoever he knew. Though I was curious to see her, I had no desire to meet her—but I did. I went up to New York with Tom on the train one afternoon, and when we stopped by the ash-heaps he jumped to his feet and, taking hold of my elbow, literally forced me from the car.

“We’re getting off,” he insisted. “I want you to meet my girl.”

I think he’d `tanked` up **a** good deal at luncheon, and his determination to have my company bordered on violence. The supercilious assumption was that on Sunday afternoon I had nothing better to do.

| a | b | c |
|---|---|---|
| I followed him  | 0 | `over` a **low** whitewashed railroad fence,  |
| I followed him  | 1 | `over` a **low** whitewashed railroad fence,  |
| I followed him  | 2 | `over` a **low** whitewashed railroad fence,  |
| I followed him  | 3 | `over` a **low** whitewashed railroad fence,  |
| I followed him  | 4 | `over` a **low** whitewashed railroad fence,  |
| I followed him  | 5 | `over` a **low** whitewashed railroad fence,  |
| I followed him  | 6 | `over` a **low** whitewashed railroad fence,  |
| I followed him  | 7 | `over` a **low** whitewashed railroad fence,  |

The interior was unprosperous and bare; the only car visible was the dust-covered wreck of a Ford which crouched in a dim corner. It had occurred to me that this shadow of a garage must be a blind, and that sumptuous and romantic apartments were concealed overhead, when the proprietor himself appeared in the door of an office, wiping his hands on a piece of waste. He was a blond, spiritless man, anaemic, and faintly handsome. When he saw us a damp gleam of hope sprang into his light blue eyes.

“Hello, Wilson, old man,” said Tom, slapping him jovially on the shoulder. “How’s business?”

“I can’t complain,” answered Wilson unconvincingly. “When are you going to sell me that car?”

“Next week; I’ve got my man working on it now.”

“Works pretty slow, don’t he?”

“No, he doesn’t,” said Tom coldly. “And if you feel that way about it, maybe I’d better sell it somewhere else after all.”

“I don’t mean that,” explained Wilson quickly. “I just meant—”

His voice faded `off` and **Tom** glanced impatiently around the garage. Then I heard footsteps on a stairs, and in a moment the thickish figure of a woman blocked out the light from the office door. She was in the middle thirties, and faintly stout, but she carried her flesh sensuously as some women can. Her face, above a spotted dress of dark blue crêpe-de-chine, contained no facet or gleam of beauty, but there was an immediately perceptible vitality about her as if the nerves of her body were continually smouldering. She smiled slowly and, walking through her husband as if he were a ghost, shook hands with Tom, looking him flush in the eye. Then she wet her lips, and without turning around spoke to her husband in a soft, coarse voice:

## Heading 159 “Get some chairs, why don’t you, so some

- “Get some chairs, `why` don’t **you,** so somebody can sit down.”

```js
const v0 = compute(0, "“Oh, sure,” agreed Wilson hurr");
const v1 = compute(1, "“Oh, sure,” agreed Wilson hurr");
const v2 = compute(2, "“Oh, sure,” agreed Wilson hurr");
const v3 = compute(3, "“Oh, sure,” agreed Wilson hurr");
const v4 = compute(4, "“Oh, sure,” agreed Wilson hurr");
```

“I want to `see` you,” **said** Tom intently. “Get on the next train.”

## Heading 162 “I’ll meet you by the newsstand on the l

- “I’ll meet you by the newsstand on the lower level.”

She nodded and moved away from him just as George Wilson emerged with two chairs from his office door.

We waited for `her` down **the** road and out of sight. It was a few days before the Fourth of July, and a grey, scrawny Italian child was setting torpedoes in a row along the railroad track.

“Terrible place, isn’t it,” said Tom, exchanging a frown with Doctor Eckleburg.

“It does her good to get away.”

“Doesn’t her husband object?”

“Wilson? He thinks she goes to see her sister in New York. He’s so dumb he doesn’t know he’s alive.”

So Tom Buchanan and his girl and I went up together to New York—or not quite together, for Mrs. Wilson sat discreetly in another car. Tom deferred that much to the sensibilities of those East Eggers who might be on the train.

She had changed her dress to a brown figured muslin, which stretched tight over her rather wide hips as Tom helped her to the platform in New York. At the newsstand she bought a copy of Town Tattle and a moving-picture magazine, and in the station drugstore some cold cream and a small flask of perfume. Upstairs, in the solemn echoing drive she let four taxicabs drive away before she selected a new one, lavender-coloured with grey upholstery, and in this we slid out from the mass of the station into the glowing sunshine. But immediately she turned sharply from the window and, leaning forward, tapped on the front glass.

“I want to `get` one **of** those dogs,” she said earnestly. “I want to get one for the apartment. They’re nice to have—a dog.”

We backed up to a grey old man who bore an absurd resemblance to John D. Rockefeller. In a basket swung from his neck cowered a dozen very recent puppies of an indeterminate breed.

“What kind are they?” asked Mrs. Wilson eagerly, as he came to the taxi-window.

“All kinds. What kind do you want, lady?”

“I’d like to get one of those police dogs; I don’t suppose you got that kind?”

The man peered `doubtfully` into **the** basket, plunged in his hand and drew one up, wriggling, by the back of the neck.

“That’s no police dog,” said Tom.

## Heading 178 “No, it’s not exactly a police dog,” sai

- “No, it’s not exactly a police dog,” said the man with disappointment in his voice
- “It’s more of an Airedale.” He passed his hand over the brown washrag of a back
- “Look at that coat
- Some coat
- That’s a dog that’ll never bother you with catching cold.”

“I think it’s cute,” said Mrs. Wilson enthusiastically. “How much is it?”

“That dog?” He looked at it admiringly. “That dog will cost you ten dollars.”

The Airedale—undoubtedly there `was` an **Airedale** concerned in it somewhere, though its feet were startlingly white—changed hands and settled down into Mrs. Wilson’s lap, where she fondled the weatherproof coat with rapture.

“Is it a boy or a girl?” she asked delicately.

## Heading 183 “That dog? That dog’s a boy.”

- “That dog? That dog’s a boy.”

“It’s a bitch,” said Tom decisively. “Here’s your money. Go and buy ten more dogs with it.”

We drove over to Fifth Avenue, warm and soft, almost pastoral, on the summer Sunday afternoon. I wouldn’t have been surprised to see a great flock of white sheep turn the corner.

“Hold on,” I `said,` “I **have** to leave you here.”

“No you don’t,” interposed Tom quickly. “Myrtle’ll be hurt if you don’t come up to the apartment. Won’t you, Myrtle?”

“Come on,” she `urged.` “I’ll **telephone** my sister Catherine. She’s said to be very beautiful by people who ought to know.”

“Well, I’d like to, but—”

We went on, `cutting` back **again** over the Park toward the West Hundreds. At 158th Street the cab stopped at one slice in a long white cake of apartment-houses. Throwing a regal homecoming glance around the neighbourhood, Mrs. Wilson gathered up her dog and her other purchases, and went haughtily in.

| a | b | c |
|---|---|---|
| “I’m going to h | 0 | ave the McKees come up,” she announced as we  |
| “I’m going to h | 1 | ave the McKees come up,” she announced as we  |
| “I’m going to h | 2 | ave the McKees come up,” she announced as we  |

The apartment was on the top floor—a small living-room, a small dining-room, a small bedroom, and a bath. The living-room was crowded to the doors with a set of tapestried furniture entirely too large for it, so that to move about was to stumble continually over scenes of ladies swinging in the gardens of Versailles. The only picture was an over-enlarged photograph, apparently a hen sitting on a blurred rock. Looked at from a distance, however, the hen resolved itself into a bonnet, and the countenance of a stout old lady beamed down into the room. Several old copies of Town Tattle lay on the table together with a copy of Simon Called Peter, and some of the small scandal magazines of Broadway. Mrs. Wilson was first concerned with the dog. A reluctant elevator boy went for a box full of straw and some milk, to which he added on his own initiative a tin of large, hard dog biscuits—one of which decomposed apathetically in the saucer of milk all afternoon. Meanwhile Tom brought out a bottle of whisky from a locked bureau door.

I have been drunk just twice in my life, and the second time was that afternoon; so everything that happened has a dim, hazy cast over it, although until after eight o’clock the apartment was full of cheerful sun. Sitting on Tom’s lap Mrs. Wilson called up several people on the telephone; then there were no cigarettes, and I went out to buy some at the drugstore on the corner. When I came back they had both disappeared, so I sat down discreetly in the living-room and read a chapter of Simon Called Peter—either it was terrible stuff or the whisky distorted things, because it didn’t make any sense to me.

Just as Tom and Myrtle (after the first drink Mrs. Wilson and I called each other by our first names) reappeared, company commenced to arrive at the apartment door.

The sister, Catherine, was a slender, worldly girl of about thirty, with a solid, sticky bob of red hair, and a complexion powdered milky white. Her eyebrows had been plucked and then drawn on again at a more rakish angle, but the efforts of nature toward the restoration of the old alignment gave a blurred air to her face. When she moved about there was an incessant clicking as innumerable pottery bracelets jingled up and down upon her arms. She came in with such a proprietary haste, and looked around so possessively at the furniture that I wondered if she lived here. But when I asked her she laughed immoderately, repeated my question aloud, and told me she lived with a girl friend at a hotel.

Mr. McKee was `a` pale, **feminine** man from the flat below. He had just shaved, for there was a white spot of lather on his cheekbone, and he was most respectful in his greeting to everyone in the room. He informed me that he was in the “artistic game,” and I gathered later that he was a photographer and had made the dim enlargement of Mrs. Wilson’s mother which hovered like an ectoplasm on the wall. His wife was shrill, languid, handsome, and horrible. She told me with pride that her husband had photographed her a hundred and twenty-seven times since they had been married.

Mrs. Wilson had changed her costume some time before, and was now attired in an elaborate afternoon dress of cream-coloured chiffon, which gave out a continual rustle as she swept about the room. With the influence of the dress her personality had also undergone a change. The intense vitality that had been so remarkable in the garage was converted into impressive hauteur. Her laughter, her gestures, her assertions became more violently affected moment by moment, and as she expanded the room grew smaller around her, until she seemed to be revolving on a noisy, creaking pivot through the smoky air.

“My dear,” she told her sister in a high, mincing shout, “most of these fellas will cheat you every time. All they think of is money. I had a woman up here last week to look at my feet, and when she gave me the bill you’d of thought she had my appendicitis out.”

“What was the name of the woman?” asked Mrs. McKee.

## Heading 200 “Mrs. Eberhardt. She goes around looking

- “Mrs
- Eberhardt
- She `goes` around **looking** at people’s feet in their own homes.”

“I like your dress,” remarked Mrs. McKee, “I think it’s adorable.”

Mrs. Wilson rejected the compliment by raising her eyebrow in disdain.

“It’s just a crazy old thing,” she said. “I just slip it on sometimes when I don’t care what I look like.”

“But it looks wonderful on you, if you know what I mean,” pursued Mrs. McKee. “If Chester could only get you in that pose I think he could make something of it.”

We all looked in silence at Mrs. Wilson, who removed a strand of hair from over her eyes and looked back at us with a brilliant smile. Mr. McKee regarded her intently with his head on one side, and then moved his hand back and forth slowly in front of his face.

“I should change the light,” he said after a moment. “I’d like to bring out the modelling of the features. And I’d try to get hold of all the back hair.”

“I wouldn’t think of changing the light,” cried Mrs. McKee. “I think it’s—”

Her husband said “Sh!” and we all looked at the subject again, whereupon Tom Buchanan yawned audibly and got to his feet.

“You McKees have `something` to **drink,”** he said. “Get some more ice and mineral water, Myrtle, before everybody goes to sleep.”

“I told that boy about the ice.” Myrtle raised her eyebrows in despair at the shiftlessness of the lower orders. “These people! You have to keep after them all the time.”

She looked at `me` and **laughed** pointlessly. Then she flounced over to the dog, kissed it with ecstasy, and swept into the kitchen, implying that a dozen chefs awaited her orders there.

“I’ve done some nice things out on Long Island,” asserted Mr. McKee.

Tom looked at him blankly.

“Two of them we have framed downstairs.”

## Heading 215 “Two what?” demanded Tom.

- “Two what?” demanded Tom.

“Two studies. One of them I call Montauk Point—The Gulls, and the other I call Montauk Point—The Sea.”

The sister Catherine sat down beside me on the couch.

“Do you live `down` on **Long** Island, too?” she inquired.

“I live at West Egg.”

“Really? I was down there at a party about a month ago. At a man named Gatsby’s. Do you know him?”

“I live next door to him.”

“Well, they say he’s a nephew or a cousin of Kaiser Wilhelm’s. That’s where all his money comes from.”

“I’m scared of him. I’d hate to have him get anything on me.”

This absorbing information about my neighbour was interrupted by Mrs. McKee’s pointing suddenly at Catherine:

“Chester, I think you could do something with her,” she broke out, but Mr. McKee only nodded in a bored way, and turned his attention to Tom.

“I’d like to `do` more **work** on Long Island, if I could get the entry. All I ask is that they should give me a start.”

“Ask Myrtle,” said Tom, breaking into a short shout of laughter as Mrs. Wilson entered with a tray. “She’ll give you a letter of introduction, won’t you, Myrtle?”

“Do what?” she asked, startled.

“You’ll give McKee a letter of introduction to your husband, so he can do some studies of him.” His lips moved silently for a moment as he invented, “ ‘George B. Wilson at the Gasoline Pump,’ or something like that.”

## Heading 230 Catherine leaned close to me and whisper

- Catherine leaned close `to` me **and** whispered in my ear:

“Neither of them `can` stand **the** person they’re married to.”

“Can’t stand them.” She looked at Myrtle and then at Tom. “What I say is, why go on living with them if they can’t stand them? If I was them I’d get a divorce and get married to each other right away.”

“Doesn’t she like Wilson either?”

The answer to this was unexpected. It came from Myrtle, who had overheard the question, and it was violent and obscene.

“You see,” cried Catherine triumphantly. She lowered her voice again. “It’s really his wife that’s keeping them apart. She’s a Catholic, and they don’t believe in divorce.”

Daisy was not a Catholic, and I was a little shocked at the elaborateness of the lie.

“When they do get married,” continued Catherine, “they’re going West to live for a while until it blows over.”

“It’d be more discreet to go to Europe.”

“Oh, do you like Europe?” she exclaimed surprisingly. “I just got back from Monte Carlo.”

“Just last year. I went over there with another girl.”

“No, we just `went` to **Monte** Carlo and back. We went by way of Marseilles. We had over twelve hundred dollars when we started, but we got gyped out of it all in two days in the private rooms. We had an awful time getting back, I can tell you. God, how I hated that town!”

> The late afternoon sky bloomed in the window for a moment like the blue honey of the Mediterranean—then the shrill voice of Mrs. McKee called me back into the room.

“I almost made a mistake, too,” she declared vigorously. “I almost married a little kike who’d been after me for years. I knew he was below me. Everybody kept saying to me: ‘Lucille, that man’s way below you!’ But if I hadn’t met Chester, he’d of got me sure.”

“Yes, but listen,” said Myrtle Wilson, nodding her head up and down, “at least you didn’t marry him.”

“Well, I married him,” said Myrtle, ambiguously. “And that’s the difference between your case and mine.”

“Why did you, Myrtle?” demanded Catherine. “Nobody forced you to.”

“I married him because I thought he was a gentleman,” she said finally. “I thought he knew something about breeding, but he wasn’t fit to lick my shoe.”

“You were crazy about him for a while,” said Catherine.

“Crazy about him!” `cried` Myrtle **incredulously.** “Who said I was crazy about him? I never was any more crazy about him than I was about that man there.”

She pointed suddenly at me, and everyone looked at me accusingly. I tried to show by my expression that I expected no affection.

“The only crazy I was was when I married him. I knew right away I made a mistake. He borrowed somebody’s best suit to get married in, and never even told me about it, and the man came after it one day when he was out: ‘Oh, is that your suit?’ I said. ‘This is the first I ever heard about it.’ But I gave it to him and then I lay down and cried to beat the band all afternoon.”

“She really ought to get away from him,” resumed Catherine to me. “They’ve been living over that garage for eleven years. And Tom’s the first sweetie she ever had.”

The bottle of whisky—a second one—was now in constant demand by all present, excepting Catherine, who “felt just as good on nothing at all.” Tom rang for the janitor and sent him for some celebrated sandwiches, which were a complete supper in themselves. I wanted to get out and walk eastward toward the park through the soft twilight, but each time I tried to go I became entangled in some wild, strident argument which pulled me back, as if with ropes, into my chair. Yet high over the city our line of yellow windows must have contributed their share of human secrecy to the casual watcher in the darkening streets, and I saw him too, looking up and wondering. I was within and without, simultaneously enchanted and repelled by the inexhaustible variety of life.

Myrtle pulled her `chair` close **to** mine, and suddenly her warm breath poured over me the story of her first meeting with Tom.

## Heading 255 “It was on the two little seats facing e

- “It was on `the` two **little** seats facing each other that are always the last ones left on the train
- I was going up to New York to see my sister and spend the night
- He had on a dress suit and patent leather shoes, and I couldn’t keep my eyes off him, but every time he looked at me I had to pretend to be looking at the advertisement over his head
- When we came into the station he was next to me, and his white shirtfront pressed against my arm, and so I told him I’d have to call a policeman, but he knew I lied
- I was so excited that when I got into a taxi with him I didn’t hardly know I wasn’t getting into a subway train

She turned to Mrs. McKee and the room rang full of her artificial laughter.

“My dear,” she cried, “I’m going to give you this dress as soon as I’m through with it. I’ve got to get another one tomorrow. I’m going to make a list of all the things I’ve got to get. A massage and a wave, and a collar for the dog, and one of those cute little ashtrays where you touch a spring, and a wreath with a black silk bow for mother’s grave that’ll last all summer. I got to write down a list so I won’t forget all the things I got to do.”

It was nine o’clock—almost immediately afterward I looked at my watch and found it was ten. Mr. McKee was asleep on a chair with his fists clenched in his lap, like a photograph of a man of action. Taking out my handkerchief I wiped from his cheek the spot of dried lather that had worried me all the afternoon.

The little dog was sitting on the table looking with blind eyes through the smoke, and from time to time groaning faintly. People disappeared, reappeared, made plans to go somewhere, and then lost each other, searched for each other, found each other a few feet away. Some time toward midnight Tom Buchanan and Mrs. Wilson stood face to face discussing, in impassioned voices, whether Mrs. Wilson had any right to mention Daisy’s name.

“Daisy! Daisy! Daisy!” shouted Mrs. Wilson. “I’ll say it whenever I want to! Daisy! Dai—”

Making a short `deft` movement, **Tom** Buchanan broke her nose with his open hand.

Then there were bloody towels upon the bathroom floor, and women’s voices scolding, and high over the confusion a long broken wail of pain. Mr. McKee awoke from his doze and started in a daze toward the door. When he had gone halfway he turned around and stared at the scene—his wife and Catherine scolding and consoling as they stumbled here and there among the crowded furniture with articles of aid, and the despairing figure on the couch, bleeding fluently, and trying to spread a copy of Town Tattle over the tapestry scenes of Versailles. Then Mr. McKee turned and continued on out the door. Taking my hat from the chandelier, I followed.

“Come to lunch `some` day,” **he** suggested, as we groaned down in the elevator.

“Keep your hands off the lever,” snapped the elevator boy.

“I beg your pardon,” said Mr. McKee with dignity, “I didn’t know I was touching it.”

“All right,” I agreed, “I’ll be glad to.”

… I was standing beside his bed and he was sitting up between the sheets, clad in his underwear, with a great portfolio in his hands.

“Beauty and the Beast … Loneliness … Old Grocery Horse … Brook’n Bridge …”

Then I was lying half asleep in the cold lower level of the Pennsylvania Station, staring at the morning Tribune, and waiting for the four o’clock train.

There was music from my neighbour’s house through the summer nights. In his blue gardens men and girls came and went like moths among the whisperings and the champagne and the stars. At high tide in the afternoon I watched his guests diving from the tower of his raft, or taking the sun on the hot sand of his beach while his two motorboats slit the waters of the Sound, drawing aquaplanes over cataracts of foam. On weekends his Rolls-Royce became an omnibus, bearing parties to and from the city between nine in the morning and long past midnight, while his station wagon scampered like a brisk yellow bug to meet all trains. And on Mondays eight servants, including an extra gardener, toiled all day with mops and scrubbing-brushes and hammers and garden-shears, repairing the ravages of the night before.

Every Friday five crates of oranges and lemons arrived from a fruiterer in New York—every Monday these same oranges and lemons left his back door in a pyramid of pulpless halves. There was a machine in the kitchen which could extract the juice of two hundred oranges in half an hour if a little button was pressed two hundred times by a butler’s thumb.

At least once a fortnight a corps of caterers came down with several hundred feet of canvas and enough coloured lights to make a Christmas tree of Gatsby’s enormous garden. On buffet tables, garnished with glistening hors-d’oeuvre, spiced baked hams crowded against salads of harlequin designs and pastry pigs and turkeys bewitched to a dark gold. In the main hall a bar with a real brass rail was set up, and stocked with gins and liquors and with cordials so long forgotten that most of his female guests were too young to know one from another.

By seven o’clock the orchestra has arrived, no thin five-piece affair, but a whole pitful of oboes and trombones and saxophones and viols and cornets and piccolos, and low and high drums. The last swimmers have come in from the beach now and are dressing upstairs; the cars from New York are parked five deep in the drive, and already the halls and salons and verandas are gaudy with primary colours, and hair bobbed in strange new ways, and shawls beyond the dreams of Castile. The bar is in full swing, and floating rounds of cocktails permeate the garden outside, until the air is alive with chatter and laughter, and casual innuendo and introductions forgotten on the spot, and enthusiastic meetings between women who never knew each other’s names.

The lights grow brighter as the earth lurches away from the sun, and now the orchestra is playing yellow cocktail music, and the opera of voices pitches a key higher. Laughter is easier minute by minute, spilled with prodigality, tipped out at a cheerful word. The groups change more swiftly, swell with new arrivals, dissolve and form in the same breath; already there are wanderers, confident girls who weave here and there among the stouter and more stable, become for a sharp, joyous moment the centre of a group, and then, excited with triumph, glide on through the sea-change of faces and voices and colour under the constantly changing light.

Suddenly one of `these` gypsies, **in** trembling opal, seizes a cocktail out of the air, dumps it down for courage and, moving her hands like Frisco, dances out alone on the canvas platform. A momentary hush; the orchestra leader varies his rhythm obligingly for her, and there is a burst of chatter as the erroneous news goes around that she is Gilda Gray’s understudy from the Follies. The party has begun.

I believe that on the first night I went to Gatsby’s house I was one of the few guests who had actually been invited. People were not invited—they went there. They got into automobiles which bore them out to Long Island, and somehow they ended up at Gatsby’s door. Once there they were introduced by somebody who knew Gatsby, and after that they conducted themselves according to the rules of behaviour associated with an amusement park. Sometimes they came and went without having met Gatsby at all, came for the party with a simplicity of heart that was its own ticket of admission.

I had been `actually` invited. **A** chauffeur in a uniform of robin’s-egg blue crossed my lawn early that Saturday morning with a surprisingly formal note from his employer: the honour would be entirely Gatsby’s, it said, if I would attend his “little party” that night. He had seen me several times, and had intended to call on me long before, but a peculiar combination of circumstances had prevented it—signed Jay Gatsby, in a majestic hand.

Dressed up in white flannels I went over to his lawn a little after seven, and wandered around rather ill at ease among swirls and eddies of people I didn’t know—though here and there was a face I had noticed on the commuting train. I was immediately struck by the number of young Englishmen dotted about; all well dressed, all looking a little hungry, and all talking in low, earnest voices to solid and prosperous Americans. I was sure that they were selling something: bonds or insurance or automobiles. They were at least agonizingly aware of the easy money in the vicinity and convinced that it was theirs for a few words in the right key.

As soon as `I` arrived **I** made an attempt to find my host, but the two or three people of whom I asked his whereabouts stared at me in such an amazed way, and denied so vehemently any knowledge of his movements, that I slunk off in the direction of the cocktail table—the only place in the garden where a single man could linger without looking purposeless and alone.

I was on my way to get roaring drunk from sheer embarrassment when Jordan Baker came out of the house and stood at the head of the marble steps, leaning a little backward and looking with contemptuous interest down into the garden.

Welcome or not, I found it necessary to attach myself to someone before I should begin to address cordial remarks to the passersby.

“Hello!” I roared, `advancing` toward **her.** My voice seemed unnaturally loud across the garden.

“I thought you might be here,” she responded absently as I came up. “I remembered you lived next door to—”

She held my hand impersonally, as a promise that she’d take care of me in a minute, and gave ear to two girls in twin yellow dresses, who stopped at the foot of the steps.

“Hello!” they cried together. “Sorry you didn’t win.”

That was for `the` golf **tournament.** She had lost in the finals the week before.

“You don’t know `who` we **are,”** said one of the girls in yellow, “but we met you here about a month ago.”

```js
const v0 = compute(0, "“You’ve dyed your hair since t");
const v1 = compute(1, "“You’ve dyed your hair since t");
const v2 = compute(2, "“You’ve dyed your hair since t");
const v3 = compute(3, "“You’ve dyed your hair since t");
const v4 = compute(4, "“You’ve dyed your hair since t");
const v5 = compute(5, "“You’ve dyed your hair since t");
const v6 = compute(6, "“You’ve dyed your hair since t");
const v7 = compute(7, "“You’ve dyed your hair since t");
const v8 = compute(8, "“You’ve dyed your hair since t");
const v9 = compute(9, "“You’ve dyed your hair since t");
const v10 = compute(10, "“You’ve dyed your hair since t");
const v11 = compute(11, "“You’ve dyed your hair since t");
const v12 = compute(12, "“You’ve dyed your hair since t");
const v13 = compute(13, "“You’ve dyed your hair since t");
const v14 = compute(14, "“You’ve dyed your hair since t");
const v15 = compute(15, "“You’ve dyed your hair since t");
const v16 = compute(16, "“You’ve dyed your hair since t");
const v17 = compute(17, "“You’ve dyed your hair since t");
const v18 = compute(18, "“You’ve dyed your hair since t");
```

“Do you come to these parties often?” inquired Jordan of the girl beside her.

“The last one `was` the **one** I met you at,” answered the girl, in an alert confident voice. She turned to her companion: “Wasn’t it for you, Lucille?”

It was for Lucille, too.

“I like to come,” Lucille said. “I never care what I do, so I always have a good time. When I was here last I tore my gown on a chair, and he asked me my name and address—inside of a week I got a package from Croirier’s with a new evening gown in it.”

“Did you keep it?” asked Jordan.

“Sure I did. I was going to wear it tonight, but it was too big in the bust and had to be altered. It was gas blue with lavender beads. Two hundred and sixty-five dollars.”

“There’s something funny `about` a **fellow** that’ll do a thing like that,” said the other girl eagerly. “He doesn’t want any trouble with anybody.”

“Who doesn’t?” I inquired.

“Gatsby. Somebody told me—”

The two girls and Jordan leaned together confidentially.

“Somebody told me they thought he killed a man once.”

A thrill passed over all of us. The three Mr. Mumbles bent forward and listened eagerly.

“I don’t think `it’s` so **much** that,” argued Lucille sceptically; “It’s more that he was a German spy during the war.”

One of the `men` nodded **in** confirmation.

“I heard that from a man who knew all about him, grew up with him in Germany,” he assured us positively.

“Oh, no,” said the first girl, “it couldn’t be that, because he was in the American army during the war.” As our credulity switched back to her she leaned forward with enthusiasm. “You look at him sometimes when he thinks nobody’s looking at him. I’ll bet he killed a man.”

She narrowed her `eyes` and **shivered.** Lucille shivered. We all turned and looked around for Gatsby. It was testimony to the romantic speculation he inspired that there were whispers about him from those who had found little that it was necessary to whisper about in this world.

The first supper—there would be another one after midnight—was now being served, and Jordan invited me to join her own party, who were spread around a table on the other side of the garden. There were three married couples and Jordan’s escort, a persistent undergraduate given to violent innuendo, and obviously under the impression that sooner or later Jordan was going to yield him up her person to a greater or lesser degree. Instead of rambling, this party had preserved a dignified homogeneity, and assumed to itself the function of representing the staid nobility of the countryside—East Egg condescending to West Egg and carefully on guard against its spectroscopic gaiety.

“Let’s get out,” whispered Jordan, after a somehow wasteful and inappropriate half-hour; “this is much too polite for me.”

We got up, and she explained that we were going to find the host: I had never met him, she said, and it was making me uneasy. The undergraduate nodded in a cynical, melancholy way.

The bar, where we glanced first, was crowded, but Gatsby was not there. She couldn’t find him from the top of the steps, and he wasn’t on the veranda. On a chance we tried an important-looking door, and walked into a high Gothic library, panelled with carved English oak, and probably transported complete from some ruin overseas.

A stout, middle-aged `man,` with **enormous** owl-eyed spectacles, was sitting somewhat drunk on the edge of a great table, staring with unsteady concentration at the shelves of books. As we entered he wheeled excitedly around and examined Jordan from head to foot.

“What do you `think?”` he **demanded** impetuously.

He waved his hand toward the bookshelves.

“About that. As a matter of fact you needn’t bother to ascertain. I ascertained. They’re real.”

## Heading 314 “Absolutely real—have pages and everythi

- “Absolutely real—have pages and everything
- I thought they’d be a nice durable cardboard
- Matter of fact, they’re absolutely real
-  Pages and—Here! Lemme show you.”

## Heading 315 Taking our scepticism for granted, he ru

- Taking our scepticism for granted, he rushed to the bookcases and returned with Volume One of the Stoddard Lectures.

“See!” he cried triumphantly. “It’s a bona-fide piece of printed matter. It fooled me. This fella’s a regular Belasco. It’s a triumph. What thoroughness! What realism! Knew when to stop, too—didn’t cut the pages. But what do you want? What do you expect?”

He snatched the book from me and replaced it hastily on its shelf, muttering that if one brick was removed the whole library was liable to collapse.

“Who brought you?” he demanded. “Or did you just come? I was brought. Most people were brought.”

Jordan looked at `him` alertly, **cheerfully,** without answering.

“I was brought `by` a **woman** named Roosevelt,” he continued. “Mrs. Claud Roosevelt. Do you know her? I met her somewhere last night. I’ve been drunk for about a week now, and I thought it might sober me up to sit in a library.”

“A little bit, `I` think. **I** can’t tell yet. I’ve only been here an hour. Did I tell you about the books? They’re real. They’re—”

We shook hands with him gravely and went back outdoors.

There was dancing `now` on **the** canvas in the garden; old men pushing young girls backward in eternal graceless circles, superior couples holding each other tortuously, fashionably, and keeping in the corners—and a great number of single girls dancing individually or relieving the orchestra for a moment of the burden of the banjo or the traps. By midnight the hilarity had increased. A celebrated tenor had sung in Italian, and a notorious contralto had sung in jazz, and between the numbers people were doing “stunts” all over the garden, while happy, vacuous bursts of laughter rose toward the summer sky. A pair of stage twins, who turned out to be the girls in yellow, did a baby act in costume, and champagne was served in glasses bigger than finger-bowls. The moon had risen higher, and floating in the Sound was a triangle of silver scales, trembling a little to the stiff, tinny drip of the banjoes on the lawn.

I was still with Jordan Baker. We were sitting at a table with a man of about my age and a rowdy little girl, who gave way upon the slightest provocation to uncontrollable laughter. I was enjoying myself now. I had taken two finger-bowls of champagne, and the scene had changed before my eyes into something significant, elemental, and profound.

At a lull in the entertainment the man looked at me and smiled.

“Your face is familiar,” he said politely. “Weren’t you in the First Division during the war?”

“Why yes. I `was` in **the** Twenty-eighth Infantry.”

```js
const v0 = compute(0, "“I was in `the` Sixteenth **un");
const v1 = compute(1, "“I was in `the` Sixteenth **un");
const v2 = compute(2, "“I was in `the` Sixteenth **un");
```

We talked for a moment about some wet, grey little villages in France. Evidently he lived in this vicinity, for he told me that he had just bought a hydroplane, and was going to try it out in the morning.

“Want to go with me, old sport? Just near the shore along the Sound.”

“Any time that suits you best.”

It was on the tip of my tongue to ask his name when Jordan looked around and smiled.

“Having a gay time now?” she inquired.

## Heading 334 “Much better.” I turned again to my new 

- “Much better.” I `turned` again **to** my new acquaintance
- “This is an unusual party for me
- I haven’t even seen the host
- I live over there—” I waved my hand at the invisible hedge in the distance, “and this man Gatsby sent over his chauffeur with an invitation.”

For a moment `he` looked **at** me as if he failed to understand.

“I’m Gatsby,” he said suddenly.

“What!” I exclaimed. “Oh, I beg your pardon.”

“I thought you `knew,` old **sport.** I’m afraid I’m not a very good host.”

```js
const v0 = compute(0, "He smiled understandingly—much");
const v1 = compute(1, "He smiled understandingly—much");
const v2 = compute(2, "He smiled understandingly—much");
const v3 = compute(3, "He smiled understandingly—much");
```

Almost at the moment when Mr. Gatsby identified himself a butler hurried toward him with the information that Chicago was calling him on the wire. He excused himself with a small bow that included each of us in turn.

“If you want `anything` just **ask** for it, old sport,” he urged me. “Excuse me. I will rejoin you later.”

When he was `gone` I **turned** immediately to Jordan—constrained to assure her of my surprise. I had expected that Mr. Gatsby would be a florid and corpulent person in his middle years.

“Who is he?” I demanded. “Do you know?”

“He’s just a man named Gatsby.”

“Where is he `from,` I **mean?** And what does he do?”

“Now you’re started on the subject,” she answered with a wan smile. “Well, he told me once he was an Oxford man.”

A dim background started to take shape behind him, but at her next remark it faded away.

“However, I don’t believe it.”

“I don’t know,” she insisted, “I just don’t think he went there.”

Something in her tone reminded me of the other girl’s “I think he killed a man,” and had the effect of stimulating my curiosity. I would have accepted without question the information that Gatsby sprang from the swamps of Louisiana or from the lower East Side of New York. That was comprehensible. But young men didn’t—at least in my provincial inexperience I believed they didn’t—drift coolly out of nowhere and buy a palace on Long Island Sound.

“Anyhow, he gives large parties,” said Jordan, changing the subject with an urban distaste for the concrete. “And I like large parties. They’re so intimate. At small parties there isn’t any privacy.”

There was the boom of a bass drum, and the voice of the orchestra leader rang out suddenly above the echolalia of the garden.

“Ladies and gentlemen,” he cried. “At the request of Mr. Gatsby we are going to play for you Mr. Vladmir Tostoff’s latest work, which attracted so much attention at Carnegie Hall last May. If you read the papers you know there was a big sensation.” He smiled with jovial condescension, and added: “Some sensation!” Whereupon everybody laughed.

```js
const v0 = compute(0, "“The piece is `known,”` he **c");
const v1 = compute(1, "“The piece is `known,”` he **c");
const v2 = compute(2, "“The piece is `known,”` he **c");
const v3 = compute(3, "“The piece is `known,”` he **c");
const v4 = compute(4, "“The piece is `known,”` he **c");
const v5 = compute(5, "“The piece is `known,”` he **c");
const v6 = compute(6, "“The piece is `known,”` he **c");
const v7 = compute(7, "“The piece is `known,”` he **c");
const v8 = compute(8, "“The piece is `known,”` he **c");
const v9 = compute(9, "“The piece is `known,”` he **c");
const v10 = compute(10, "“The piece is `known,”` he **c");
const v11 = compute(11, "“The piece is `known,”` he **c");
const v12 = compute(12, "“The piece is `known,”` he **c");
const v13 = compute(13, "“The piece is `known,”` he **c");
const v14 = compute(14, "“The piece is `known,”` he **c");
const v15 = compute(15, "“The piece is `known,”` he **c");
const v16 = compute(16, "“The piece is `known,”` he **c");
const v17 = compute(17, "“The piece is `known,”` he **c");
const v18 = compute(18, "“The piece is `known,”` he **c");
const v19 = compute(19, "“The piece is `known,”` he **c");
const v20 = compute(20, "“The piece is `known,”` he **c");
const v21 = compute(21, "“The piece is `known,”` he **c");
```

The nature of Mr. Tostoff’s composition eluded me, because just as it began my eyes fell on Gatsby, standing alone on the marble steps and looking from one group to another with approving eyes. His tanned skin was drawn attractively tight on his face and his short hair looked as though it were trimmed every day. I could see nothing sinister about him. I wondered if the fact that he was not drinking helped to set him off from his guests, for it seemed to me that he grew more correct as the fraternal hilarity increased. When the “Jazz History of the World” was over, girls were putting their heads on men’s shoulders in a puppyish, convivial way, girls were swooning backward playfully into men’s arms, even into groups, knowing that someone would arrest their falls—but no one swooned backward on Gatsby, and no French bob touched Gatsby’s shoulder, and no singing quartets were formed with Gatsby’s head for one link.

Gatsby’s butler was suddenly standing beside us.

“Miss Baker?” he inquired. “I beg your pardon, but Mr. Gatsby would like to speak to you alone.”

“With me?” she exclaimed in surprise.

## Heading 359 She got up slowly, raising her eyebrows 

```js
const v0 = compute(0, "She got up `slowly,` raising *");
const v1 = compute(1, "She got up `slowly,` raising *");
const v2 = compute(2, "She got up `slowly,` raising *");
const v3 = compute(3, "She got up `slowly,` raising *");
const v4 = compute(4, "She got up `slowly,` raising *");
const v5 = compute(5, "She got up `slowly,` raising *");
const v6 = compute(6, "She got up `slowly,` raising *");
const v7 = compute(7, "She got up `slowly,` raising *");
const v8 = compute(8, "She got up `slowly,` raising *");
const v9 = compute(9, "She got up `slowly,` raising *");
const v10 = compute(10, "She got up `slowly,` raising *");
const v11 = compute(11, "She got up `slowly,` raising *");
const v12 = compute(12, "She got up `slowly,` raising *");
const v13 = compute(13, "She got up `slowly,` raising *");
const v14 = compute(14, "She got up `slowly,` raising *");
const v15 = compute(15, "She got up `slowly,` raising *");
const v16 = compute(16, "She got up `slowly,` raising *");
const v17 = compute(17, "She got up `slowly,` raising *");
const v18 = compute(18, "She got up `slowly,` raising *");
```

I was alone and it was almost two. For some time confused and intriguing sounds had issued from a long, many-windowed room which overhung the terrace. Eluding Jordan’s undergraduate, who was now engaged in an obstetrical conversation with two chorus girls, and who implored me to join him, I went inside.

The large room `was` full **of** people. One of the girls in yellow was playing the piano, and beside her stood a tall, red-haired young lady from a famous chorus, engaged in song. She had drunk a quantity of champagne, and during the course of her song she had decided, ineptly, that everything was very, very sad—she was not only singing, she was weeping too. Whenever there was a pause in the song she filled it with gasping, broken sobs, and then took up the lyric again in a quavering soprano. The tears coursed down her cheeks—not freely, however, for when they came into contact with her heavily beaded eyelashes they assumed an inky colour, and pursued the rest of their way in slow black rivulets. A humorous suggestion was made that she sing the notes on her face, whereupon she threw up her hands, sank into a chair, and went off into a deep vinous sleep.

“She had a fight with a man who says he’s her husband,” explained a girl at my elbow.

I looked around. Most of the remaining women were now having fights with men said to be their husbands. Even Jordan’s party, the quartet from East Egg, were rent asunder by dissension. One of the men was talking with curious intensity to a young actress, and his wife, after attempting to laugh at the situation in a dignified and indifferent way, broke down entirely and resorted to flank attacks—at intervals she appeared suddenly at his side like an angry diamond, and hissed: “You promised!” into his ear.

The reluctance to go home was not confined to wayward men. The hall was at present occupied by two deplorably sober men and their highly indignant wives. The wives were sympathizing with each other in slightly raised voices.

## Heading 365 “Whenever he sees I’m having a good time

- “Whenever he sees I’m having a good time he wants to go home.”

| a | b | c |
|---|---|---|
| “Never heard an | 0 | ything so selfish in my life.” |
| “Never heard an | 1 | ything so selfish in my life.” |

“We’re always the first ones to leave.”

## Heading 368 “Well, we’re almost the last tonight,” s

```js
const v0 = compute(0, "“Well, we’re almost `the` last");
const v1 = compute(1, "“Well, we’re almost `the` last");
const v2 = compute(2, "“Well, we’re almost `the` last");
const v3 = compute(3, "“Well, we’re almost `the` last");
const v4 = compute(4, "“Well, we’re almost `the` last");
const v5 = compute(5, "“Well, we’re almost `the` last");
const v6 = compute(6, "“Well, we’re almost `the` last");
```

In spite of the wives’ agreement that such malevolence was beyond credibility, the dispute ended in a short struggle, and both wives were lifted, kicking, into the night.

As I waited for my hat in the hall the door of the library opened and Jordan Baker and Gatsby came out together. He was saying some last word to her, but the eagerness in his manner tightened abruptly into formality as several people approached him to say goodbye.

| a | b | c |
|---|---|---|
| Jordan’s party  | 0 | were calling impatiently to her from the porc |
| Jordan’s party  | 1 | were calling impatiently to her from the porc |
| Jordan’s party  | 2 | were calling impatiently to her from the porc |
| Jordan’s party  | 3 | were calling impatiently to her from the porc |
| Jordan’s party  | 4 | were calling impatiently to her from the porc |
| Jordan’s party  | 5 | were calling impatiently to her from the porc |

“I’ve just heard the most amazing thing,” she whispered. “How long were we in there?”

“Why, about an hour.”

“It was … simply amazing,” she repeated abstractedly. “But I swore I wouldn’t tell it and here I am tantalizing you.” She yawned gracefully in my face. “Please come and see me … Phone book … Under the name of Mrs. Sigourney Howard … My aunt …” She was hurrying off as she talked—her brown hand waved a jaunty salute as she melted into her party at the door.

> Rather ashamed that on my first appearance I had stayed so late, I joined the last of Gatsby’s guests, who were clustered around him. I wanted to explain that I’d hunted for him early in the evening and to apologize for not having known him in the garden.

“Don’t mention it,” he enjoined me eagerly. “Don’t give it another thought, old sport.” The familiar expression held no more familiarity than the hand which reassuringly brushed my shoulder. “And don’t forget we’re going up in the hydroplane tomorrow morning, at nine o’clock.”

Then the butler, behind his shoulder:

“Philadelphia wants you on the phone, sir.”

“All right, in a minute. Tell them I’ll be right there … Good night.”

“Good night.” He `smiled—and` suddenly **there** seemed to be a pleasant significance in having been among the last to go, as if he had desired it all the time. “Good night, old sport … Good night.”

But as I walked down the steps I saw that the evening was not quite over. Fifty feet from the door a dozen headlights illuminated a bizarre and tumultuous scene. In the ditch beside the road, right side up, but violently shorn of one wheel, rested a new coupé which had left Gatsby’s drive not two minutes before. The sharp jut of a wall accounted for the detachment of the wheel, which was now getting considerable attention from half a dozen curious chauffeurs. However, as they had left their cars blocking the road, a harsh, discordant din from those in the rear had been audible for some time, and added to the already violent confusion of the scene.

| a | b | c |
|---|---|---|
| A man in a long | 0 |  duster had dismounted from the wreck and now |
| A man in a long | 1 |  duster had dismounted from the wreck and now |
| A man in a long | 2 |  duster had dismounted from the wreck and now |
| A man in a long | 3 |  duster had dismounted from the wreck and now |
| A man in a long | 4 |  duster had dismounted from the wreck and now |
| A man in a long | 5 |  duster had dismounted from the wreck and now |

```js
const v0 = compute(0, "“See!” he explained. “It went ");
const v1 = compute(1, "“See!” he explained. “It went ");
const v2 = compute(2, "“See!” he explained. “It went ");
const v3 = compute(3, "“See!” he explained. “It went ");
const v4 = compute(4, "“See!” he explained. “It went ");
const v5 = compute(5, "“See!” he explained. “It went ");
const v6 = compute(6, "“See!” he explained. “It went ");
const v7 = compute(7, "“See!” he explained. “It went ");
const v8 = compute(8, "“See!” he explained. “It went ");
const v9 = compute(9, "“See!” he explained. “It went ");
const v10 = compute(10, "“See!” he explained. “It went ");
const v11 = compute(11, "“See!” he explained. “It went ");
const v12 = compute(12, "“See!” he explained. “It went ");
const v13 = compute(13, "“See!” he explained. “It went ");
const v14 = compute(14, "“See!” he explained. “It went ");
const v15 = compute(15, "“See!” he explained. “It went ");
const v16 = compute(16, "“See!” he explained. “It went ");
const v17 = compute(17, "“See!” he explained. “It went ");
const v18 = compute(18, "“See!” he explained. “It went ");
const v19 = compute(19, "“See!” he explained. “It went ");
const v20 = compute(20, "“See!” he explained. “It went ");
const v21 = compute(21, "“See!” he explained. “It went ");
const v22 = compute(22, "“See!” he explained. “It went ");
```

The fact was infinitely astonishing to him, and I recognized first the unusual quality of wonder, and then the man—it was the late patron of Gatsby’s library.

He shrugged his shoulders.

“I know nothing whatever about mechanics,” he said decisively.

## Heading 387 “But how did it happen? Did you run into

- “But how did `it` happen? **Did** you run into the wall?”

“Don’t ask me,” said Owl Eyes, washing his hands of the whole matter. “I know very little about driving—next to nothing. It happened, and that’s all I know.”

“Well, if you’re a poor driver you oughtn’t to try driving at night.”

“But I wasn’t `even` trying,” **he** explained indignantly, “I wasn’t even trying.”

An awed hush fell upon the bystanders.

“Do you want to commit suicide?”

“You’re lucky it `was` just **a** wheel! A bad driver and not even trying!”

“You don’t understand,” `explained` the **criminal.** “I wasn’t driving. There’s another man in the car.”

## Heading 395 The shock that followed this declaration

- The shock that followed this declaration found voice in a sustained “Ah-h-h!” as the door of the coupé swung slowly open
- The crowd—it was now a crowd—stepped back involuntarily, and when the door had opened wide there was a ghostly pause
- Then, very gradually, part by part, a pale, dangling individual stepped out of the wreck, pawing tentatively at the ground with a large uncertain dancing shoe.

Blinded by the `glare` of **the** headlights and confused by the incessant groaning of the horns, the apparition stood swaying for a moment before he perceived the man in the duster.

“Wha’s matter?” he inquired calmly. “Did we run outa gas?”

Half a dozen fingers pointed at the amputated wheel—he stared at it for a moment, and then looked upward as though he suspected that it had dropped from the sky.

“It came off,” someone explained.

“At first I din’ notice we’d stopped.”

A pause. Then, taking a long breath and straightening his shoulders, he remarked in a determined voice:

## Heading 402 “Wonder’ff tell me where there’s a gas’l

- “Wonder’ff tell me `where` there’s **a** gas’line station?”

At least a `dozen` men, **some** of them a little better off than he was, explained to him that wheel and car were no longer joined by any physical bond.

“Back out,” he suggested after a moment. “Put her in reverse.”

“But the wheel’s off!”

“No harm in trying,” he said.

The caterwauling horns had reached a crescendo and I turned away and cut across the lawn toward home. I glanced back once. A wafer of a moon was shining over Gatsby’s house, making the night fine as before, and surviving the laughter and the sound of his still glowing garden. A sudden emptiness seemed to flow now from the windows and the great doors, endowing with complete isolation the figure of the host, who stood on the porch, his hand up in a formal gesture of farewell.

------------------------------------------------------------------------

Reading over what I have written so far, I see I have given the impression that the events of three nights several weeks apart were all that absorbed me. On the contrary, they were merely casual events in a crowded summer, and, until much later, they absorbed me infinitely less than my personal affairs.

Most of the time I worked. In the early morning the sun threw my shadow westward as I hurried down the white chasms of lower New York to the Probity Trust. I knew the other clerks and young bond-salesmen by their first names, and lunched with them in dark, crowded restaurants on little pig sausages and mashed potatoes and coffee. I even had a short affair with a girl who lived in Jersey City and worked in the accounting department, but her brother began throwing mean looks in my direction, so when she went on her vacation in July I let it blow quietly away.

I took dinner usually at the Yale Club—for some reason it was the gloomiest event of my day—and then I went upstairs to the library and studied investments and securities for a conscientious hour. There were generally a few rioters around, but they never came into the library, so it was a good place to work. After that, if the night was mellow, I strolled down Madison Avenue past the old Murray Hill Hotel, and over 33rd Street to the Pennsylvania Station.

I began to like New York, the racy, adventurous feel of it at night, and the satisfaction that the constant flicker of men and women and machines gives to the restless eye. I liked to walk up Fifth Avenue and pick out romantic women from the crowd and imagine that in a few minutes I was going to enter into their lives, and no one would ever know or disapprove. Sometimes, in my mind, I followed them to their apartments on the corners of hidden streets, and they turned and smiled back at me before they faded through a door into warm darkness. At the enchanted metropolitan twilight I felt a haunting loneliness sometimes, and felt it in others—poor young clerks who loitered in front of windows waiting until it was time for a solitary restaurant dinner—young clerks in the dusk, wasting the most poignant moments of night and life.

Again at eight o’clock, when the dark lanes of the Forties were lined five deep with throbbing taxicabs, bound for the theatre district, I felt a sinking in my heart. Forms leaned together in the taxis as they waited, and voices sang, and there was laughter from unheard jokes, and lighted cigarettes made unintelligible circles inside. Imagining that I, too, was hurrying towards gaiety and sharing their intimate excitement, I wished them well.

For a while I lost sight of Jordan Baker, and then in midsummer I found her again. At first I was flattered to go places with her, because she was a golf champion, and everyone knew her name. Then it was something more. I wasn’t actually in love, but I felt a sort of tender curiosity. The bored haughty face that she turned to the world concealed something—most affectations conceal something eventually, even though they don’t in the beginning—and one day I found what it was. When we were on a house-party together up in Warwick, she left a borrowed car out in the rain with the top down, and then lied about it—and suddenly I remembered the story about her that had eluded me that night at Daisy’s. At her first big golf tournament there was a row that nearly reached the newspapers—a suggestion that she had moved her ball from a bad lie in the semifinal round. The thing approached the proportions of a scandal—then died away. A caddy retracted his statement, and the only other witness admitted that he might have been mistaken. The incident and the name had remained together in my mind.

Jordan Baker instinctively `avoided` clever, **shrewd** men, and now I saw that this was because she felt safer on a plane where any divergence from a code would be thought impossible. She was incurably dishonest. She wasn’t able to endure being at a disadvantage and, given this unwillingness, I suppose she had begun dealing in subterfuges when she was very young in order to keep that cool, insolent smile turned to the world and yet satisfy the demands of her hard, jaunty body.

It made no difference to me. Dishonesty in a woman is a thing you never blame deeply—I was casually sorry, and then I forgot. It was on that same house-party that we had a curious conversation about driving a car. It started because she passed so close to some workmen that our fender flicked a button on one man’s coat.

“You’re a rotten driver,” I protested. “Either you ought to be more careful, or you oughtn’t to drive at all.”

“Well, other people are,” she said lightly.

“What’s that got to do with it?”

```js
const v0 = compute(0, "“They’ll keep out of my way,” ");
const v1 = compute(1, "“They’ll keep out of my way,” ");
const v2 = compute(2, "“They’ll keep out of my way,” ");
const v3 = compute(3, "“They’ll keep out of my way,” ");
const v4 = compute(4, "“They’ll keep out of my way,” ");
const v5 = compute(5, "“They’ll keep out of my way,” ");
const v6 = compute(6, "“They’ll keep out of my way,” ");
const v7 = compute(7, "“They’ll keep out of my way,” ");
const v8 = compute(8, "“They’ll keep out of my way,” ");
const v9 = compute(9, "“They’ll keep out of my way,” ");
const v10 = compute(10, "“They’ll keep out of my way,” ");
```

“Suppose you met `somebody` just **as** careless as yourself.”

“I hope I never will,” she answered. “I hate careless people. That’s why I like you.”

Her grey, sun-strained `eyes` stared **straight** ahead, but she had deliberately shifted our relations, and for a moment I thought I loved her. But I am slow-thinking and full of interior rules that act as brakes on my desires, and I knew that first I had to get myself definitely out of that tangle back home. I’d been writing letters once a week and signing them: “Love, Nick,” and all I could think of was how, when that certain girl played tennis, a faint moustache of perspiration appeared on her upper lip. Nevertheless there was a vague understanding that had to be tactfully broken off before I was free.

Everyone suspects himself of at least one of the cardinal virtues, and this is mine: I am one of the few honest people that I have ever known.

On Sunday morning while church bells rang in the villages alongshore, the world and its mistress returned to Gatsby’s house and twinkled hilariously on his lawn.

“He’s a bootlegger,” said the young ladies, moving somewhere between his cocktails and his flowers. “One time he killed a man who had found out that he was nephew to Von Hindenburg and second cousin to the devil. Reach me a rose, honey, and pour me a last drop into that there crystal glass.”

## Heading 427 Once I wrote down on the empty spaces of

- Once I wrote down on the empty spaces of a timetable the names of those who came to Gatsby’s house that summer
- It is an old timetable now, disintegrating at its folds, and headed “This schedule in effect July 5th, 1922.” But I can still read the grey names, and they will give you a better impression than my generalities of those who accepted Gatsby’s hospitality and paid him the subtle tribute of knowing nothing whatever about him.

From East Egg, then, came the Chester Beckers and the Leeches, and a man named Bunsen, whom I knew at Yale, and Doctor Webster Civet, who was drowned last summer up in Maine. And the Hornbeams and the Willie Voltaires, and a whole clan named Blackbuck, who always gathered in a corner and flipped up their noses like goats at whosoever came near. And the Ismays and the Chrysties (or rather Hubert Auerbach and Mr. Chrystie’s wife), and Edgar Beaver, whose hair, they say, turned cotton-white one winter afternoon for no good reason at all.

Clarence Endive was from East Egg, as I remember. He came only once, in white knickerbockers, and had a fight with a bum named Etty in the garden. From farther out on the Island came the Cheadles and the O. R. P. Schraeders, and the Stonewall Jackson Abrams of Georgia, and the Fishguards and the Ripley Snells. Snell was there three days before he went to the penitentiary, so drunk out on the gravel drive that Mrs. Ulysses Swett’s automobile ran over his right hand. The Dancies came, too, and S. B. Whitebait, who was well over sixty, and Maurice A. Flink, and the Hammerheads, and Beluga the tobacco importer, and Beluga’s girls.

From West Egg came the Poles and the Mulreadys and Cecil Roebuck and Cecil Schoen and Gulick the State senator and Newton Orchid, who controlled Films Par Excellence, and Eckhaust and Clyde Cohen and Don S. Schwartz (the son) and Arthur McCarty, all connected with the movies in one way or another. And the Catlips and the Bembergs and G. Earl Muldoon, brother to that Muldoon who afterward strangled his wife. Da Fontano the promoter came there, and Ed Legros and James B. (“Rot-Gut”) Ferret and the De Jongs and Ernest Lilly—they came to gamble, and when Ferret wandered into the garden it meant he was cleaned out and Associated Traction would have to fluctuate profitably next day.
